file = open("sample.txt", "w")

file.write("Hello! This is my Python file handling assignment.\n")
file.write("This file was created using Python.\n")
file.write("I used the open() and write() functions.")

file.close()

print("Content written to sample.txt successfully.")